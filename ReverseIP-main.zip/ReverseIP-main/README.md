# ReverseIP

REVERSE IP 


USAGE : bash rev.sh
