import os
import re
import threading
import concurrent.futures
try:
	import requests
except ImportError:
	exit("install modul requests dulu !")

if not os.path.exists("result"):
	os.makedirs("result")
if not os.path.exists("result/_Grab.txt"):
	open("result/_Grab.txt","w").write("")

class grab:
	def __init__(self):
		self.ses = requests.Session()

	def Writter(self,Value):
		if Value in open("result/_Grab.txt").read().splitlines():
			return
		open("result/_Grab.txt","a+").write(f"{Value}\n")

	def gSite(self,Y,M,D,Page,Thread):
		req = self.ses.get(f"https://www.thesiterank.com/newly-registered-domain-names-by-date/{Y}-{M}-{D}/{Page}")
		allSite = re.findall('<div class=col-md-4 style=height:27px;><a href="(.*?)">(.*?)</a>',req.text)
		for Site in allSite:
			with concurrent.futures.ThreadPoolExecutor(max_workers=Thread/2) as Th:
				Th.submit(self.Writter,Site[1])
		print(f"[•] Grabbing {len(allSite)} from page {Page} !")

main = grab()
Year = input("\033[37;1m[+] ""\033[31;1mmasukkan tahun : ")
Month = input("\033[37;1m[+] ""\033[34;1mmasukkan bulan : ")
Day = input("\033[37;1m[+] ""\033[33;1mmasukkan tanggal: ")
Page = int(input("\033[37;1m[+] ""\033[35;1mdari halaman : "))
tPage = int(input("\033[37;1m[+] ""\033[31;1mke halaman : "))
Thread = int(input("\033[37;1m[+] ""\033[30;1mkecepatan : "))
print("\033[37;1m[+] ""\033[32;1mmulai bos !")
while True:
	with concurrent.futures.ThreadPoolExecutor(max_workers=Thread) as Th:
		Th.submit(main.gSite,Year,Month,Day,Page,Thread)
	if Page == tPage:
		break
	Page += 1