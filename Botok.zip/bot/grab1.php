<?php
error_reporting(0);
flush();

echo PHP_EOL . 'Note : input tanggal dan bulan dengan 0 dibelakangnya jika dari dari angka 1 - 9' . PHP_EOL;
echo 'Contoh : tanggal = 01' . PHP_EOL . PHP_EOL;
$tahun = readline('Masukan Tahun Sekarang : ');
$bulan = readline('Masukan Bulan : ');
$tanggal = readline('Masukan Tanggal : ');
$sampai = readline('Sampai Tanggal : ');


function site($site, $from)
{
    $setopt = array(
        CURLOPT_URL => "$site/$from",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_CONNECTTIMEOUT => 60,
        CURLOPT_USERAGENT => "Mozilla/5.0 (X11; CrOS x86_64 9901.77.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.97 Safari/537.36"
    );
    $ch = curl_init();
    curl_setopt_array($ch, $setopt);
    return curl_exec($ch);
    curl_close($ch);
}

function curlreverse($url)
{
    $setopt = array(
        CURLOPT_URL => "https://osint.sh/reverseip/",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => "domain=$url",
        CURLOPT_POST => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (X11; CrOS x86_64 9901.77.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.97 Safari/537.36'
    );
    $ch = curl_init();
    curl_setopt_array($ch, $setopt);
    $exe = curl_exec($ch);
    curl_close($ch);
    return $exe;
}

function getreverse($site, $from)
{
    // $url = preg_replace('/^www\./', '', $parse['host']);
    echo "$from | Reverse ip Dari Domain : $site";
    $www = "www." . $site;
    $ip = gethostbyname($www);
    $reverse = curlreverse($ip);
    $list = preg_match_all("/<td data-th=\"Domain\">\s(.*?)<\/td>/i", $reverse, $listdomain);
    $getdomain = str_replace(' ', '', $listdomain[1]);
    $result = array_filter(array_unique($getdomain));
    foreach ($result as $key) {
        $savereverse = fopen('reverseip.txt', 'a+');
        fwrite($savereverse, $key . PHP_EOL);
        fclose($savereverse);
    }
}

function seo($page)
{
    $pageseo = site('https://www.dubdomain.com', "index.php?page=$page");
    $last = preg_match('/<a href="\/index.php(.*?)">Last<\/a>/', $pageseo, $seolast);
    $rep = str_replace('?page=', '', $seolast[1]);

    while ($page <= $rep) {
        $seo = site('https://www.dubdomain.com', "index.php?page=$page");
        $getlist = preg_match_all('/title=(.*?)>(.*?)<\/a><td>/', $seo, $list);
        $echoseo = "\nGrab Site Seo Dari Page : $page";

        echo $echoseo;
        foreach ($list[2] as $key) {
            // $exp = explode(PHP_EOL, $key);
            // foreach ($exp as $reverse) {
            //     getreverse($reverse, $echoseo);
            // }
            $saveseo = fopen('seosite.txt', 'a+');
            fwrite($saveseo, $key . PHP_EOL);
            fclose($saveseo);
        }
        $page++;
    }
}

function getpage($tahun, $bulan, $tanggal, $page, $fullpage)
{
    while ($page <= $fullpage) {
        $echograb = "\nGrab Site Dari Tanggal : $tanggal Dan Page : $page";
        echo $echograb;
        $url = site('https://www.dubdomain.com', "/new-domain-registered-dates/$tahun-$bulan-$tanggal/$page");
        $domain = preg_match_all('/<a href="https:\/\/www.dubdomain.com\/q.php(.*?)">(.*?)<\/a>/i', $url, $getdomain);
        foreach ($getdomain[2] as $key) {
            $save = fopen('resultgrabber.txt', 'a+');
            fwrite($save, $key . PHP_EOL);
            fclose($save);
        }
        $page++;
    }
}

function getpage2($tahun, $bulan, $tanggal, $page, $fullpage)
{
    while ($page <= $fullpage) {
        $echograb = "\nGrab Site 2 Dari Tanggal : $tanggal Dan Page : $page";
        echo $echograb;
        $url = site('https://www.cubdomain.com', "domains-registered-by-date/$tahun-$bulan-$tanggal/$page");
        $domain = preg_match_all('/site\/(.*?)">(.*?)<\/a>/i', $url, $getdomain);
        foreach ($getdomain[2] as $key) {
            $save = fopen('resultgrabber.txt', 'a+');
            fwrite($save, $key . PHP_EOL);
            fclose($save);
        }
        $page++;
    }
}

function gettanngal()
{
    $getdate = site('https://www.dubdomain.com', "new-domain-registered/1");
    $lastdate = preg_match_all('/href=\/new-domain-registered\/(.*?)>(.*?)<\/a>/', $getdate, $getlastpage);

    $date = site('https://www.dubdomain.com', 'new-domain-registered/' . end($getlastpage[1]));
    $getlastdate = preg_match_all('/\/new-domain-registered-dates\/(.*?)\/(.*?)>/', $date, $nicedate);
    echo 'Page Yang Bisa Di Grab Hanya Dari Tahun ' . $nicedate[1][0] . ' Hingga Sekarang!!' . PHP_EOL;
}

while ($tanggal <= $sampai) {
    $page = 1;

    $getpage = site('https://www.dubdomain.com', "new-domain-registered-dates/$tahun-$bulan-$tanggal/1");
    $lastpage = preg_match_all('/<a class="page-link disabled" href=\/new-domain-registered-dates\/(.*?)\/(.*?)>/', $getpage, $pagel);
    $fullpage = $pagel[2][0];

    $getpage2 = site('https://www.cubdomain.com', "domains-registered-by-date/$tahun-$bulan-$tanggal/1");
    $lastpage = preg_match_all('/<a class="page-link" href="\/domains-registered-by-date\/(.*?)\/(.*?)">(.*?)<\/a><\/li>/', $getpage2, $pagel2);
    $fullpage2 = $pagel2[2][4];

    if ($fullpage == 0) {
        echo PHP_EOL . "Tidak Ada Page Yang Bisa Di Grab Dari Tahun $tahun-$bulan-$tanggal Hingga Tanggal $sampai!!" . PHP_EOL;
        gettanngal();
        break;
    } else {
        seo($page);
        getpage($tahun, $bulan, $tanggal, $page, $fullpage);
        getpage2($tahun, $bulan, $tanggal, $page, $fullpage2);
    }
    $tanggal++;
}
