<?php
error_reporting(0);
flush();

echo PHP_EOL . 'Note : input tanggal dan bulan dengan 0 dibelakangnya jika dari dari angka 1 - 9' . PHP_EOL;
echo 'Contoh : tanggal = 01' . PHP_EOL . PHP_EOL;
$tahun = readline('Masukan Tahun Sekarang : ');
$bulan = readline('Masukan Bulan : ');
$tanggal = readline('Masukan Tanggal : ');
$sampai = readline('Sampai Tanggal : ');


function site($site, $from)
{
    $setopt = array(
        CURLOPT_URL => "$site/$from",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_CONNECTTIMEOUT => 60,
        CURLOPT_USERAGENT => "Mozilla/5.0 (X11; CrOS x86_64 9901.77.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.97 Safari/537.36"
    );
    $ch = curl_init();
    curl_setopt_array($ch, $setopt);
    return curl_exec($ch);
    curl_close($ch);
}

function getpage2($tahun, $bulan, $tanggal, $page, $fullpage)
{
    while ($page <= $fullpage) {
        $url = site('https://websitebiography.com', "new_domain_registrations/$tahun-$bulan-$tanggal/$page");
        $totaldomain = preg_match('/Total Registered Domains: (.*?) <p>/', $url, $alldomain);
        $echograb = "\nGrab Site Dari Tanggal : $tanggal Dan Page : $page | All Page : $fullpage | Total All Domain : " . $alldomain[1];
        echo $echograb;
        $domain = preg_match_all("/<a href='https:\/\/(.*?).websitebiography.com'/i", $url, $getdomain);
        foreach ($getdomain[1] as $key) {
            $save = fopen('resultgrabber.txt', 'a+');
            fwrite($save, $key . PHP_EOL);
            fclose($save);
        }
        $page++;
    }
}

function gettanggal()
{
    $getdate = site('https://www.thesiterank.com', "newly-registered-domain-names/1");
    $lastdate = preg_match_all('/href=\/newly-registered-domain-names\/(.*?)>(.*?)<\/a>/', $getdate, $getlastpage);

    $date = site('https://www.thesiterank.com', 'newly-registered-domain-names/' . end($getlastpage[1]));
    $getlastdate = preg_match_all('/href=https:\/\/www.thesiterank.com\/newly-registered-domain-names-by-date\/(.*?)\/(.*?)>/', $date, $nicedate);
    echo 'Page Yang Bisa Di Grab Hanya Dari Tahun ' . end($nicedate[1]) . ' Hingga Sekarang!!' . PHP_EOL;
}

while ($tanggal <= $sampai) {
    $page = 1;

    $getpage = site('https://www.thesiterank.com/', "newly-registered-domain-names-by-date/$tahun-$bulan-$tanggal/1");
    $lastpage = preg_match_all('/<a class="page-link disabled" href=\/newly-registered-domain-names-by-date\/(.*?)\/(.*?)>/', $getpage, $pagel);
    $fullpage = $pagel[2][0];

    $getpage2 = site('https://websitebiography.com/', "new_domain_registrations/$tahun-$bulan-$tanggal/1");
    $lastpage = preg_match_all("/<a href='new_domain_registrations\/(.*?)\/(.*?)'>(.*?)<\/a> /", $getpage2, $pagel2);
    $fullpage2 = end($pagel2[2]);

    if ($fullpage == 0) {
        echo PHP_EOL . "Tidak Ada Page Yang Bisa Di Grab Dari Tahun $tahun-$bulan-$tanggal Hingga Tanggal $sampai!!" . PHP_EOL;
        gettanggal();
        break;
    } else {
        getpage2($tahun, $bulan, $tanggal, $page, $fullpage2);
    }
    $tanggal++;
}
