# coded : AkasakaID

import os
import concurrent.futures
try:
	import requests
	from colorama import *
except ImportError:
	exit("module not installed")

if not os.path.exists("result"):
	os.makedirs("result")

open("result/result_rev_ip.txt","a+")

init(autoreset=True)
merah = Fore.LIGHTRED_EX
kuning = Fore.LIGHTYELLOW_EX
hijau = Fore.LIGHTGREEN_EX
biru = Fore.LIGHTBLUE_EX
magenta = Fore.LIGHTMAGENTA_EX
cyan = Fore.LIGHTCYAN_EX
hitam = Fore.LIGHTBLACK_EX
putih = Fore.LIGHTWHITE_EX
reset = Fore.RESET

class reverseip:
	def __init__(self):
		self.url = "http://xfell-v3.herokuapp.com/kunyuk?ip="
		self.ses = requests.Session()
		self.ses.headers.update({"user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64"})

	def rev(self,site):
		try:
			req = self.ses.get(f"{self.url}{site}")
			resultRev = req.text.splitlines()
			print(f"{putih}[{hijau}+{putih}] {cyan}{site} {putih}--> {magenta}{len(resultRev)} {hijau}domains")
			if len(resultRev) != 0:
				[open("result/result_rev_ip.txt","a+").write(f"{res}\n") for res in resultRev]
		except requests.exceptions.ConnectionError:
			print(f"{putih}[{merah}!{putih}] {merah}no internet !")

	def main(self):
		os.system("cls" if not os.name == "nt" else "clear")
		ListSite = open(input("input list : ")).read().splitlines()
		with concurrent.futures.ThreadPoolExecutor(max_workers=int(input("input thread : "))) as tx:
			[tx.submit(self.rev,Site) for Site in ListSite]
		print(f"{putih}[{kuning}!{putih}] {kuning}saved in {hijau}result/result_rev_ip.txt")

try:
	app = reverseip()
	app.main()
except KeyboardInterrupt:
	exit()